def get_user_input():
    num1 = float(input("Input first num: "))
    operator = input("Input operation (+, -, *, /, **): ")
    num2 = float(input("Input second num: "))
    return num1, operator, num2
def choise_mode():
    num12 = float(input("Input first num: "))
    operatorSQ = input("Input figure(SQ, CIR)")
    num22 = float(input("Input second num: "))
    return num12, num22, operatorSQ

def display_result(result):
    print(f"Result: {result}")