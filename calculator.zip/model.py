def calculate(num1, num2, operator):
    if operator == '+':
        return num1 + num2
    elif operator == '-':
        return num1 - num2
    elif operator == '**':
        return num1**num2
    elif operator == '*':
        return num1 * num2
    elif operator == '/':
        if num2 != 0:
            return num1 / num2
        else:
            return "DROP IT!!!!!"
def calculateSQ(num12, num22, operatorSQ):
    if operatorSQ == "SQ":
        return num12 * num22
    elif operatorSQ == "CIR":
        return num12 ** 2 *3,14