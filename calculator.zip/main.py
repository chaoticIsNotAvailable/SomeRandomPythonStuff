import controller
while True:
    choise = int(input('Choose mode 1 - Simple Calculator, 2 - Square calculator'))

    if __name__ == "__main__":
        if choise == 1:
            calculator = controller.run()
            calculator.run()
        else:
            calculatorSQ = controller.runSQ()
            calculatorSQ.runSQ()
