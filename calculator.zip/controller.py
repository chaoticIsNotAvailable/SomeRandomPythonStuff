import view
import model
import main


def run():
    while True:
        num1, operator, num2 = view.get_user_input()
        result = model.calculate(num1, num2, operator)
        view.display_result(result)


def runSQ():
    while True:
        num12, operatorSQ, num22 = view.choise_mode()
        result = model.calculateSQ(num12, operatorSQ, num22)
        view.display_result(result)



